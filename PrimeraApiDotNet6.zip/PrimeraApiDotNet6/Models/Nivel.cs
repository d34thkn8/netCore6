﻿namespace PrimeraApiDotNet6.Models
{
    public enum Nivel
    {
        Basico,
        Intermedio,
        Avanzado
    }
}
